// নতুন পণ্য যোগ করতে নিচের মতো object কপি করুন। ছবি images ফোল্ডারে রাখুন।
const PRODUCTS=[
{id:1,name:'DC Table Light',price:350,category:'Lighting',image:'images/dc-table-light.jpg'},
{id:2,name:'Emergency Light',price:350,category:'Lighting',image:'images/emergency-light.jpg'},
{id:3,name:'TP4056 Charging Module',price:25,category:'Electronics',image:'images/tp4056.jpg'},
{id:4,name:'2600mAh Brand New Battery',price:170,category:'Battery',image:'images/2600mah-battery.jpg'}
];
